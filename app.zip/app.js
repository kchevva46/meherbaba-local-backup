import React, { useState, useRef } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, ScrollView, ActivityIndicator, KeyboardAvoidingView, Platform, Image, Alert } from 'react-native';

export default function App() {
  // Authentication & Chat States
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [question, setQuestion] = useState('');
  const [chatHistory, setChatHistory] = useState([{ id: 1, text: "Welcome to MeherBaba.AI.", from: 'bot' }]);
  const [loading, setLoading] = useState(false);
  const scrollViewRef = useRef();

  // IMPORTANT: Replace this with your computer's current IP or your Public URL
  const BASE_URL = 'http://localhost:8080/ask';

  const handleLogin = async () => {
    if (!userId || !password) return Alert.alert("Error", "Enter credentials");
    try {
      const response = await fetch(`${BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: userId, password: password }),
      });
      const data = await response.json();
      if (data.success) setIsLoggedIn(true);
      else Alert.alert("Failed", data.message);
    } catch (e) { Alert.alert("Error", "Server unreachable"); }
  };

  const sendToGPT = async () => {
    if (!question.trim()) return;
    const userMsg = { id: Date.now(), text: question, from: 'user' };
    setChatHistory(prev => [...prev, userMsg]);
    setLoading(true);
    setQuestion('');

    try {
      const response = await fetch(`${BASE_URL}/ask`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: userMsg.text }),
      });
      const data = await response.json();
      setChatHistory(prev => [...prev, { id: Date.now()+1, text: data.answer || "Error", from: 'bot' }]);
    } catch (e) { setChatHistory(prev => [...prev, { id: Date.now()+1, text: "Network Error", from: 'bot' }]); }
    finally { setLoading(false); }
  };

  if (!isLoggedIn) {
    return (
      <View style={styles.loginContainer}>
        <Image source={require('./assets/icon.png')} style={styles.loginLogo} />
        <Text style={styles.loginTitle}>MeherBaba.AI</Text>
        <TextInput style={styles.loginInput} placeholder="User ID" onChangeText={setUserId} autoCapitalize="none" />
        <TextInput style={styles.loginInput} placeholder="Password" secureTextEntry onChangeText={setPassword} />
        <TouchableOpacity style={styles.loginButton} onPress={handleLogin}><Text style={styles.loginButtonText}>Login</Text></TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Image source={require('./assets/icon.png')} style={styles.headerIcon} />
          <Text style={styles.headerTitle}>MeherBaba.AI</Text>
        </View>
      </View>
      <ScrollView style={styles.chatArea} ref={scrollViewRef} onContentSizeChange={() => scrollViewRef.current.scrollToEnd()}>
        {chatHistory.map(msg => (
          <View key={msg.id} style={[styles.messageRow, msg.from === 'user' ? styles.userRow : styles.botRow]}>
            <View style={[styles.bubble, msg.from === 'user' ? styles.userBubble : styles.botBubble]}>
              <Text style={msg.from === 'user' ? styles.userText : styles.botText}>{msg.text}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <View style={styles.inputContainer}>
          <TextInput style={styles.input} placeholder="Ask a question..." value={question} onChangeText={setQuestion} multiline />
          <TouchableOpacity style={styles.sendButton} onPress={sendToGPT} disabled={loading}><Text style={styles.sendButtonText}>Send</Text></TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA' },
  loginContainer: { flex: 1, backgroundColor: '#FFF', justifyContent: 'center', padding: 40 },
  loginLogo: { width: 100, height: 100, borderRadius: 50, alignSelf: 'center', marginBottom: 20 },
  loginTitle: { fontSize: 26, fontWeight: 'bold', textAlign: 'center', marginBottom: 30 },
  loginInput: { backgroundColor: '#F2F2F7', borderRadius: 10, padding: 15, marginBottom: 15 },
  loginButton: { backgroundColor: '#007AFF', padding: 15, borderRadius: 10, alignItems: 'center' },
  loginButtonText: { color: '#FFF', fontWeight: 'bold' },
  header: { paddingTop: 60, paddingBottom: 15, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#EEE' },
  headerContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  headerIcon: { width: 35, height: 35, borderRadius: 17.5, marginRight: 10 },
  headerTitle: { fontSize: 18, fontWeight: '700' },
  chatArea: { flex: 1, paddingHorizontal: 15 },
  messageRow: { marginVertical: 8, flexDirection: 'row' },
  userRow: { justifyContent: 'flex-end' },
  botRow: { justifyContent: 'flex-start' },
  bubble: { maxWidth: '80%', padding: 12, borderRadius: 18 },
  userBubble: { backgroundColor: '#007AFF' },
  botBubble: { backgroundColor: '#E9E9EB' },
  userText: { color: '#FFF' },
  botText: { color: '#000' },
  inputContainer: { flexDirection: 'row', padding: 15, backgroundColor: '#FFF', borderTopWidth: 1, borderTopColor: '#EEE' },
  input: { flex: 1, backgroundColor: '#F2F2F7', borderRadius: 20, paddingHorizontal: 15, paddingVertical: 10 },
  sendButton: { marginLeft: 10, justifyContent: 'center', backgroundColor: '#007AFF', borderRadius: 20, paddingHorizontal: 20 },
  sendButtonText: { color: '#FFF', fontWeight: 'bold' },
});

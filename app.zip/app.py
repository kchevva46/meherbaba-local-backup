import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from openai import OpenAI
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
# CORS ensures your iPhone app can communicate with this server
CORS(app)

# SECURITY: Uses environment variables for the API key. 
# Replace the second string with your actual key for local testing.
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "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")
client = OpenAI(api_key=OPENAI_API_KEY)

# Simple user database with a hashed password
users = {
    "meher_admin": generate_password_hash("baba123")
}

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    # Securely verify credentials
    if username in users and check_password_hash(users[username], password):
        return jsonify({"success": True, "message": "Login successful"}), 200
    
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

@app.route('/ask', methods=['POST'])
def ask_gpt():
    try:
        data = request.json
        user_question = data.get("question", "Hello!")

        # Your specific archival assistant instructions
        instructions = """
        You are Beloved Archives bot, a strict document-grounded archival assistant.
        ... (Insert your full instructions here) ...
        """

        # Using your specific Vector Store ID
        tools = [{"type": "file_search", "vector_store_ids": ['vs_694d9825e0a48191a210172fc49320da']}]

        response = client.responses.create(
            model="gpt-4-turbo",
            input=[
                {"role": "developer", "content": instructions},
                {"role": "user", "content": user_question}
            ],
            tools=tools
        )

        return jsonify({"answer": response.output_text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Dynamic port for cloud hosting; defaults to 8080 locally
    port = int(os.environ.get("PORT", 8080))
    # host='0.0.0.0' listens on all available network interfaces
    app.run(host='0.0.0.0', port=port)
    